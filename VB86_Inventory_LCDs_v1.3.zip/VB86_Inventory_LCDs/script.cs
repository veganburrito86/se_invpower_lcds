﻿/*
 * R e a d m e
 * -----------
 * VB86_Inventory_LCDs v1.3
 * by VeganBurrito86
 * 
 * ***IMPORTANT NEW ARGUMENT OPTIONS AT BOTTOM OF THIS FILE*** 
 * 
 * Script to count all inventory and display ore lists, ingot lists, volume and mass information, and power information.
 * 
 * Name your LCD panels "invPanel XXXXXX", replace "XXXXXX" with one of these options:
 * 
 * percent    |    orelist    |    ingotslist    |    ore    |    ingots    |    
 * mass       |    power      |    storedpower   |
 * 
 * Cockpits are more complicated, use Argument as follows:
 * 
 * cockpit <NAME> # -<TYPE>
 * 
 * where <NAME> is the name of the desired cockpit to change, # is the screen number to change, and <TYPE> (*with* the hyphen '-' in front of it!) is one of the following:
 * 
 * -percent
 * -orelist
 * -ingotslist
 * -ore
 * -ingots
 * -mass
 * -power
 * -storedpower
 * 
 * - - - "-ore" and "-ingots" are the list of those items AND some additional inventory information on one screen (%inventory used, total volume and mass)
 * - - - "-power" shows the full power information screen, while "-storedpower" just shows a percent of stored power remaining.
 * 
 * 
 * You can run the script with these arguments:
 * "initpanels" - looks for newly-placed screens and updates them
 * "findcontainers" - looks for newly-placed blocks with inventories to count
 * "update_off" - stops the script from updating screens
 * "update_on" - continue updating screens after using "update_off"
 */
MyCommandLine á =new MyCommandLine();Dictionary<string,Action>à=new Dictionary<string,Action>(StringComparer.
OrdinalIgnoreCase);const UpdateType ß=UpdateType.Trigger|UpdateType.Terminal;IMyTextSurface Þ;IMyTextSurface Ý;IMyCubeGrid Ü;IMyCockpit Û
;IMyTextSurface Ú;Dictionary<IMyTextSurface,string>Ù=new Dictionary<IMyTextSurface,string>();Dictionary<IMyTextPanel,
string>Ø=new Dictionary<IMyTextPanel,string>();List<IMyTerminalBlock>Ö=new List<IMyTerminalBlock>();List<MyInventoryItem>Õ=new
List<MyInventoryItem>();List<IMyPowerProducer>Ô=new List<IMyPowerProducer>();Dictionary<string,double>â=new Dictionary<
string,double>();Dictionary<string,string>Ó=new Dictionary<string,string>();Dictionary<string,double>Ñ=new Dictionary<string,
double>();Dictionary<string,string>Ð=new Dictionary<string,string>();int Ï=0;double Î=0;double Í=0;double Ì=0;double Ë=0;
string Ê;string É;string È;string Ç;string Æ;string Å;string Ò;string ã;string ò;string þ;Program(){Runtime.UpdateFrequency=
UpdateFrequency.None;à["initpanels"]=ü;à["findcontainers"]=ù;à["cockpit"]=õ;à["update_on"]=å;à["update_off"]=ä;à["inspect"]=Ã;Þ=Me.
GetSurface(0);Ý=Me.GetSurface(1);Ü=Me.CubeGrid;Þ.ContentType=ContentType.TEXT_AND_IMAGE;Þ.FontSize=1.0f;Þ.Alignment=TextAlignment.
CENTER;Þ.TextPadding=39.3f;Þ.FontColor=Color.DarkGreen;Ý.ContentType=ContentType.TEXT_AND_IMAGE;Ý.FontSize=2.6f;Ý.Alignment=
TextAlignment.CENTER;Ý.TextPadding=14.5f;Ý.FontColor=Color.DarkGreen;GridTerminalSystem.GetBlocksOfType<IMyPowerProducer>(Ô,ý=>ý.
IsSameConstructAs(Me));Ó.Add("Cobalt"," Co");Ó.Add("Gold"," Au");Ó.Add("Ice","Ice");Ó.Add("Iron"," Fe");Ó.Add("Magnesium"," Mg");Ó.Add(
"Nickel"," Ni");Ó.Add("Platinum"," Pt");Ó.Add("Scrap","Scr");Ó.Add("Silicon"," Si");Ó.Add("Silver"," Ag");Ó.Add("Stone","Stn");Ó
.Add("Uranium","  U");Ð.Add("Cobalt","Co");Ð.Add("Gold","Au");Ð.Add("Iron","Fe");Ð.Add("Magnesium","Mg");Ð.Add("Nickel",
"Ni");Ð.Add("Platinum","Pt");Ð.Add("Silicon","Si");Ð.Add("Silver","Ag");Ð.Add("Uranium"," U");foreach(KeyValuePair<string,
string>Y in Ó){â.Add(Y.Key,0);}foreach(KeyValuePair<string,string>Y in Ð){Ñ.Add(Y.Key,0);}ü();ù();å();Echo(
$"\n|-{Ü.CustomName}-|");Echo($"{Ö.Count} inventories found.");}void ü(){List<IMyTextPanel>û=new List<IMyTextPanel>();GridTerminalSystem.
GetBlocksOfType<IMyTextPanel>(û,ú=>ú.CustomName.Contains("invPanel"));if(û==null){return;}foreach(var Ä in û){if(Ä.IsSameConstructAs(Me
)){Echo($"Found panel {Ä.CustomName}...");Ä.Alignment=TextAlignment.LEFT;Ä.Font="Monospace";Ä.BackgroundColor=Color.Black
;Ä.ContentType=ContentType.TEXT_AND_IMAGE;Ä.Enabled=true;Ä.TextPadding=1.5f;Ä.FontSize=0.5f;if(Ä.CustomName.Contains(
"percent")){if(!Ø.ContainsKey(Ä)){Ø.Add(Ä,"percent");}else{Ø[Ä]="percent";}Ä.Alignment=TextAlignment.CENTER;Ä.FontSize=2.5f;Ä.
TextPadding=16.0f;}else if(Ä.CustomName.Contains("storedpower")){if(!Ø.ContainsKey(Ä)){Ø.Add(Ä,"storedpower");}else{Ø[Ä]=
"storedpower";}Ä.Alignment=TextAlignment.CENTER;Ä.FontSize=2.0f;Ä.TextPadding=21.0f;}else if(Ä.CustomName.Contains("power")){Ä.
FontSize=0.42f;if(!Ø.ContainsKey(Ä)){Ø.Add(Ä,"power");}else{Ø[Ä]="power";}}else if(Ä.CustomName.Contains("ingotslist")){if(!Ø.
ContainsKey(Ä)){Ø.Add(Ä,"ingotslist");}else{Ø[Ä]="ingotslist";}}else if(Ä.CustomName.Contains("ingots")){if(!Ø.ContainsKey(Ä)){Ø.
Add(Ä,"ingots");}else{Ø[Ä]="ingots";}}else if(Ä.CustomName.Contains("orelist")){if(!Ø.ContainsKey(Ä)){Ø.Add(Ä,"orelist");}
else{Ø[Ä]="orelist";}}else if(Ä.CustomName.Contains("ore")){Ä.FontSize=0.5f;if(!Ø.ContainsKey(Ä)){Ø.Add(Ä,"ore");}else{Ø[Ä]=
"ore";}}else if(Ä.CustomName.Contains("mass")){if(!Ø.ContainsKey(Ä)){Ø.Add(Ä,"mass");}else{Ø[Ä]="mass";}Ä.Alignment=
TextAlignment.CENTER;Ä.FontSize=1.75f;Ä.TextPadding=36.0f;}}}}void ù(){GridTerminalSystem.GetBlocks(Ö);var ø=Ö.ToArray();foreach(
IMyTerminalBlock ö in ø){if(ö.HasInventory==false|ö.IsSameConstructAs(Me)==false){Ö.Remove(ö);}}}void õ(){List<IMyCockpit>ô=new List<
IMyCockpit>();GridTerminalSystem.GetBlocksOfType<IMyCockpit>(ô,ñ=>ñ.IsSameConstructAs(Me));if(ô==null){Echo(
"Could not find ANY cockpits.");return;}string ó=á.Argument(1);foreach(var ñ in ô){if(ñ.CustomName.Equals(á.Argument(1),StringComparison.
OrdinalIgnoreCase)){Û=ñ;}}if(Û==null){Echo($"Could not find a cockpit with the name '{ó}'.");return;}if(á.Argument(2).ToString()==null){
Echo("No screen index given. Use 'cockpit <COCKPITNAME> <SCREENNUMBER>' to set which LCD on the cockpit you want to display this."
);return;}int ð=int.Parse(á.Argument(2));Echo($"Found cockpit '{Û.CustomName}'.");Ú=Û.GetSurface(ð);if(Ú==null){Echo(
$"Could not find a screen with index {ð} on {Û.CustomName}.");return;}bool ï=á.Switch("noformat");if(!ï){Ú.Alignment=TextAlignment.LEFT;Ú.FontColor=Color.DarkGreen;Ú.
BackgroundColor=Color.Black;Ú.ContentType=ContentType.TEXT_AND_IMAGE;Ú.TextPadding=2.5f;Ú.FontSize=0.7f;}string î="";bool í=á.Switch(
"percent");bool ì=á.Switch("orelist");bool ë=á.Switch("ingotslist");bool ê=á.Switch("ore");bool é=á.Switch("ingots");bool è=á.
Switch("mass");bool ç=á.Switch("power");bool æ=á.Switch("storedpower");if(í){î="percent";if(!ï){Ú.Alignment=TextAlignment.
CENTER;Ú.FontSize=3.0f;Ú.TextPadding=18f;}}else if(ì){î="orelist";if(!ï){Ú.Alignment=TextAlignment.LEFT;Ú.FontSize=0.85f;Ú.
TextPadding=2.0f;}}else if(ë){î="ingotslist";if(!ï){Ú.Alignment=TextAlignment.LEFT;Ú.FontSize=0.85f;Ú.TextPadding=2.0f;}}else if(è)
{î="mass";if(!ï){Ú.Alignment=TextAlignment.CENTER;Ú.FontSize=2.0f;Ú.TextPadding=30f;}}else if(ê){î="ore";if(!ï){Ú.
FontSize=0.6f;}}else if(é){î="ingots";if(!ï){Ú.FontSize=0.6f;}}else if(ç){î="power";if(!ï){Ú.FontSize=0.6f;}}else if(æ){î=
"storedpower";if(!ï){Ú.FontSize=1.2f;Ú.Alignment=TextAlignment.CENTER;Ú.TextPadding=18f;}}if(Ù.ContainsKey(Ú)){Ù[Ú]=î;}else{Ù.Add(Ú,î
);}}void å(){Runtime.UpdateFrequency=UpdateFrequency.Update100;Þ.WriteText("Inventory + Power\nLCD Program\n\n- Online -"
);}void ä(){Runtime.UpdateFrequency=UpdateFrequency.None;Þ.FontColor=Color.DarkRed;Þ.WriteText(
"Inventory + Power\nLCD Program\n\n- OFFLINE -");}void Ã(){Echo("Inspect doesn't work yet.");}void Z(){Î=0;Í=0;Ì=0;Ë=0;foreach(KeyValuePair<string,string>Y in Ó){â[Y.
Key]=0;}foreach(KeyValuePair<string,string>Y in Ð){Ñ[Y.Key]=0;}string X;Ï=0;for(int E=0;E<Ö.Count;E++){for(int W=0;W<Ö[E].
InventoryCount;W++){Ï++;Õ.Clear();IMyInventory V=Ö[E].GetInventory(W);V.GetItems(Õ);foreach(MyInventoryItem U in Õ){string T=U.Type.
SubtypeId.ToString();if(U.Type.TypeId=="MyObjectBuilder_Ore"&â.ContainsKey(T)){â[T]+=(double)U.Amount;}else if(U.Type.TypeId==
"MyObjectBuilder_Ingot"&Ñ.ContainsKey(T)){Ñ[T]+=(double)U.Amount;double S=(double)U.Amount;}}Ë+=(double)V.CurrentMass;Í+=(double)V.
CurrentVolume;Ì+=(double)V.MaxVolume;}}K(Í,Ì,out Î,out X);Í*=1000;Ì*=1000;string R="L";if(Í>=1000&Í<1000000){Í/=1000;Ì/=1000;R="kL";}
else if(Í>=1000000){Í/=1000000;Ì/=1000000;R="ML";}double Q=(double)Ë;string P="kg";if(Q>=1000&Q<1000000){Q/=1000;P="t";}else
if(Q>=1000000){Q/=1000000;P="kt";}Æ=$"{Í.ToString("N2")} / {Ì.ToString("N2")}{R}";Å=$"{Q.ToString("N2")}{P}";string O=
$" {Î.ToString("N2")}%\nVolume: {Æ} \n  Mass: {Å}\n";string N=X+O;È=$"{Î.ToString("N2")}%\nINVENTORY\nUSED";Ç=$"{Î.ToString("N2")}%\nINVENTORY\nUSED";Ò="\n";foreach(var M
in â){Ò+=$"{Ó[M.Key]}: {M.Value.ToString("N2")}kg\n";}ã="\n";foreach(var L in Ñ){ã+=
$"{Ð[L.Key]}: {L.Value.ToString("N2")}kg\n";}Ê="| - - - INVENTORY - - - |\n"+X+O+"\n| - - - ORE - - - |\n"+Ò;É="| - - - INVENTORY - - - |\n"+X+O+
"\n| - - - INGOTS - - - |\n"+ã;}void K(double B,double J,out double I,out string H){H="[";I=(B/J)*100;if(I>=99.9){I=100;}int G=(int)Math.Floor(I/4);
int F=25-G;for(int E=0;E<G;E++){H+="|";}for(int E=0;E<F;E++){H+=" ";}H+="]";}string D(string C,float B,float J){string A=""
;double I=0;K(B,J,out I,out A);string Â=A;Â+=$" {I.ToString("N2")}% {C} ({B.ToString("N2")}MW)\n";return Â;}void À(){
float º=0;float µ=0;float ª=0;float z=0;float y=0;float x=0;float w=0;float v=0;float u=0;float t=0;float s=0;float r=0;float
Á=0;foreach(IMyPowerProducer q in Ô){º+=q.MaxOutput;µ+=q.CurrentOutput;if(q is IMyBatteryBlock){IMyBatteryBlock o=(
IMyBatteryBlock)q;z+=o.CurrentStoredPower;y+=o.MaxStoredPower;x+=o.CurrentInput;v+=o.CurrentOutput;w+=o.MaxInput;u+=o.MaxOutput;ª++;}
else if(q.BlockDefinition.TypeIdString=="MyObjectBuilder_WindTurbine"){Á+=q.CurrentOutput;}else if(q is IMySolarPanel){
IMySolarPanel n=(IMySolarPanel)q;t+=n.CurrentOutput;}else if(q is IMyReactor){IMyReactor m=(IMyReactor)q;s+=m.CurrentOutput;}else if(
q.BlockDefinition.SubtypeId=="LargeHydrogenEngine"){r+=q.CurrentOutput;}}string H="";double I=0;K(µ,º,out I,out H);ò=
"| - - - TOTAL POWER OUTPUT INFO - - - -|\n\n";ò+=H;ò+=$" {I.ToString("N2")}% USAGE\n";ò+=$"{µ.ToString("N2")} / {º.ToString("N2")} MW";ò+="\n\n";string k="";double h
=0;K(z,y,out h,out k);þ=$"{h.ToString("N2")}%\nStored Power\nRemaining";ò+="| - - - BATTERY INFO - - - - - - - - |\n\n";ò
+=k;ò+=$" {h.ToString("N2")}% CAPACITY\n";ò+=$"{z.ToString("N2")} / {y.ToString("N2")} MW\n\n";ò+=
$"{ª} Batteries On Grid\n";ò+=$"Current/Max Total Input: {x.ToString("N2")} / {w.ToString("N2")} MW\n";ò+=
$"Current/Max Total Output: {v.ToString("N2")} / {u.ToString("N2")} MW\n\n";ò+="| - - - OUTPUT DISTRIBUTION INFO - - - |\n\n";ò+=D("BATTERIES",v,µ);ò+=D("WIND",Á,µ);ò+=D("SOLAR",t,µ);ò+=D(
"REACTOR",s,µ);ò+=D("HYDROGEN",r,µ);}void Main(string g,UpdateType f){int e=Ø.Count+Ù.Count;Ý.WriteText($"Updating {e} displays.\n{Ø.Count} panels registered.\n{Ù.Count} cockpit LCDs registered.\n{Ö.Count} inventories tracked."
);if((f&ß)!=0){if(á.TryParse(g)){Action d;string b=á.Argument(0);if(b==null){Echo("No command specified.");}else if(à.
TryGetValue(á.Argument(0),out d)){d();}else{Echo($"Unknown command '{b}'");}}}if(0!=(f&UpdateType.Update100)){Z();À();if(Ø!=null){
foreach(var Ä in Ø){if(Ä.Value=="percent"){Ä.Key.WriteText(È);}else if(Ä.Value=="ore"){Ä.Key.WriteText(Ê);}else if(Ä.Value==
"orelist"){Ä.Key.WriteText(Ò);}else if(Ä.Value=="ingots"){Ä.Key.WriteText(É);}else if(Ä.Value=="ingotslist"){Ä.Key.WriteText(ã);}
else if(Ä.Value=="mass"){Ä.Key.WriteText(Å);}else if(Ä.Value=="power"){Ä.Key.WriteText(ò);}else if(Ä.Value=="storedpower"){Ä
.Key.WriteText(þ);}}}if(Ù!=null){foreach(var a in Ù){if(a.Value=="percent"){a.Key.WriteText(Ç);}else if(a.Value==
"orelist"){a.Key.WriteText(Ò);}else if(a.Value=="ingotslist"){a.Key.WriteText(ã);}else if(a.Value=="mass"){a.Key.WriteText(Å);}
else if(a.Value=="ore"){a.Key.WriteText(Ê);}else if(a.Value=="ingots"){a.Key.WriteText(É);}else if(a.Value=="power"){a.Key.
WriteText(ò);}else if(a.Value=="storedpower"){a.Key.WriteText(þ);}}}}}